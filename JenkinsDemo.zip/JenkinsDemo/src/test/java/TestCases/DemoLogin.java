package TestCases;

import org.testng.annotations.Test;

public class DemoLogin {

    @Test  // This annotation is required for TestNG to detect and execute this method
    public void testLogin() {
        System.out.println("Hello, this is a TestNG test!");
    }
}
